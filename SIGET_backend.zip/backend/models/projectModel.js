const mongoose = require("mongoose");

const projectSchema = new mongoose.Schema(
  {
    nombreConvenio: {
      type: String,
      required: true,
    },
    contraparte: {
      type: String,
      required: true,
    },
    departamento: {
      type: String,
      required: true,
    },
    provincia: {
      type: String,
      required: true,
    },
    distrito: {
      type: String,
      required: true,
    },
    ubigeo: {
      type: Number,
      required: true,
    },
    servicioPriorizado: {
      type: String,
      required: true,
    },
    nombreIdeaProyecto: {
      type: String,
      required: true,
    },
    cui: {
      type: Number,
      required: true,
    },
    ci: {
      type: Number,
      required: true,
    },
    firmaConvenio: {
      type: Date,
      required: true,
    },
    inicioConvenio: {
      type: Date,
      required: true,
    },
    numeroBeneficiarios: {
      type: Number,
      required: true,
    },
    montoInversion: {
      type: Number,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Project", projectSchema);
