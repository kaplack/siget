import React from "react";
import ProjectForm from "../components/ProjectForm";

function NewProject() {
  return <ProjectForm modo="crear" />;
}

export default NewProject;
