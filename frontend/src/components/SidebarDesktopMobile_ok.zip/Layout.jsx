import React, { useState, useEffect } from "react";
import Sidebar from "./Sidebar";
import Header from "./Header";
import { Outlet } from "react-router-dom";

function Layout() {
  const [collapsed, setCollapsed] = useState(true);
  const [isMobile, setIsMobile] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    window.addEventListener("resize", handleResize);
    handleResize();

    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const toggleCollapse = () => setCollapsed(!collapsed);
  const toggleMobile = () => setMobileOpen(!mobileOpen);
  const closeMobile = () => setMobileOpen(false);

  const sidebarWidth = collapsed ? 80 : 250;

  return (
    <div className="d-flex flex-column">
      {/* Header solo visible en mobile */}
      {isMobile && <Header toggleMobile={toggleMobile} />}

      <div className="d-flex">
        <Sidebar
          isMobile={isMobile}
          collapsed={collapsed}
          toggleCollapse={toggleCollapse}
          mobileOpen={mobileOpen}
          closeMobile={closeMobile}
        />

        <div
          className="flex-grow-1 p-3"
          style={{
            marginLeft: isMobile ? 0 : sidebarWidth,
            transition: "margin-left 0.3s",
            minHeight: "100vh",
          }}
        >
          <Outlet />
        </div>
      </div>
    </div>
  );
}

export default Layout;
