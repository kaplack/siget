import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  FaProjectDiagram,
  FaCalendarPlus,
  FaHome,
  FaAngleDoubleLeft,
  FaAngleDoubleRight,
  FaTimes,
} from "react-icons/fa";

function Sidebar({
  isMobile,
  collapsed,
  toggleCollapse,
  mobileOpen,
  closeMobile,
}) {
  const sidebarWidth = collapsed ? 80 : 250;
  const [showLabels, setShowLabels] = useState(!collapsed);

  useEffect(() => {
    let timer;

    if (!collapsed) {
      timer = setTimeout(() => setShowLabels(true), 300);
    } else {
      setShowLabels(false);
    }

    return () => clearTimeout(timer);
  }, [collapsed]);

  // Versión Desktop
  const desktopSidebar = (
    <div
      className="bg-dark text-white p-2 position-fixed top-0 start-0 h-100"
      style={{ width: sidebarWidth, zIndex: 1000, transition: "width 0.3s" }}
    >
      <div className="d-flex justify-content-end mb-4">
        <button className="btn btn-sm btn-light" onClick={toggleCollapse}>
          {collapsed ? <FaAngleDoubleRight /> : <FaAngleDoubleLeft />}
        </button>
      </div>

      <ul className="nav flex-column">
        <li className="nav-item mb-2">
          <Link
            className="nav-link text-white d-flex align-items-center"
            to="/app/dashboard"
          >
            <FaHome className="me-2" /> {showLabels && "Dashboard"}
          </Link>
        </li>
        <li className="nav-item mb-2">
          <Link
            className="nav-link text-white d-flex align-items-center"
            to="/app/project/new"
          >
            <FaProjectDiagram className="me-2" />{" "}
            {showLabels && "Nuevo Proyecto"}
          </Link>
        </li>
        <li className="nav-item mb-2">
          <Link
            className="nav-link text-white d-flex align-items-center"
            to="/app/proyectos"
          >
            <FaCalendarPlus className="me-2" />{" "}
            {showLabels && "Lista Proyectos"}
          </Link>
        </li>
      </ul>
    </div>
  );

  // Versión Mobile
  const mobileSidebar = (
    <div
      className="position-fixed top-0 start-0 h-100"
      style={{
        width: "250px",
        zIndex: 2000,
        backgroundColor: "#212529",
        color: "white",
        transition: "transform 0.3s ease-in-out",
        transform: mobileOpen ? "translateX(0)" : "translateX(-100%)",
      }}
    >
      <div className="p-3 d-flex justify-content-between align-items-center mb-4">
        <h5>SIGET</h5>
        <button className="btn btn-light" onClick={closeMobile}>
          <FaTimes />
        </button>
      </div>

      <ul className="nav flex-column p-3">
        <li className="nav-item mb-2">
          <Link
            className="nav-link text-white d-flex align-items-center"
            to="/app/dashboard"
            onClick={closeMobile}
          >
            <FaHome className="me-2" /> Dashboard
          </Link>
        </li>
        <li className="nav-item mb-2">
          <Link
            className="nav-link text-white d-flex align-items-center"
            to="/app/project/new"
            onClick={closeMobile}
          >
            <FaProjectDiagram className="me-2" /> Nuevo Proyecto
          </Link>
        </li>
        <li className="nav-item mb-2">
          <Link
            className="nav-link text-white d-flex align-items-center"
            to="/app/proyectos"
            onClick={closeMobile}
          >
            <FaCalendarPlus className="me-2" /> Lista Proyectos
          </Link>
        </li>
      </ul>
    </div>
  );

  return isMobile ? mobileSidebar : desktopSidebar;
}

export default Sidebar;
