import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Header from "./components/Header";
import PrivateRoute from "./components/PrivateRoute";
import NewProject from "./pages/NewProject";
import ListaProyectos from "./pages/ListaProyectos";

function App() {
  return (
    <>
      <Router>
        <div className="container">
          <Header />
          <Routes>
            <Route path="/" element={<Home />}></Route>
            <Route path="/register" element={<Register />}></Route>
            <Route path="/project/new" element={<NewProject />} />
            <Route path="/proyectos" element={<ListaProyectos />} />
            <Route
              path="/dashboard"
              element={
                <PrivateRoute>
                  <h1>Dashboard</h1>
                </PrivateRoute>
              }
            ></Route>
          </Routes>
        </div>
      </Router>
      <ToastContainer />
    </>
  );
}

export default App;
