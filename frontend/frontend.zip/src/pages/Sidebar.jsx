import { useState } from "react";
import { FaHome, FaTasks, FaChartLine } from "react-icons/fa";

export default function Sidebar() {
  const [isExpanded, setIsExpanded] = useState(false);

  const toggleSidebar = () => setIsExpanded(!isExpanded);

  return (
    <div
      className={`h-screen bg-gray-800 transition-all duration-300 ${
        isExpanded ? "w-64" : "w-20"
      }`}
    >
      <button className="p-2 text-white" onClick={toggleSidebar}>
        {isExpanded ? "<" : ">"}
      </button>

      <div className="mt-4 flex flex-col gap-4">
        <SidebarItem
          icon={<FaHome />}
          label="Registro"
          isExpanded={isExpanded}
        />
        <SidebarItem
          icon={<FaTasks />}
          label="Programación"
          isExpanded={isExpanded}
        />
        <SidebarItem
          icon={<FaChartLine />}
          label="Seguimiento"
          isExpanded={isExpanded}
        />
      </div>
    </div>
  );
}

function SidebarItem({ icon, label, isExpanded }) {
  return (
    <div className="flex items-center gap-4 text-white px-2 py-2 hover:bg-gray-700 cursor-pointer">
      <div className="text-xl">{icon}</div>
      {isExpanded && <span>{label}</span>}
    </div>
  );
}
