import React from "react";

function ListaProyectos() {
  return (
    <section className="content">
      <h1>Listado de proyectos</h1>
      <p>Aquí se mostrarán los proyectos registrados.</p>
      {/* Aquí irá la tabla o lista de proyectos */}
    </section>
  );
}

export default ListaProyectos;
